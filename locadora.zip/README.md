Video Locadora

Projeto como requisito parcial para a disciplina de Laborátório de Programaçao

O Sistema desenvolivido é um sistema para gerenciamento de catálogo, clientes e o relacionamento entre clietnes de locadora via locação de vídeos
